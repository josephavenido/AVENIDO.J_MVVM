package com.example.mvvmuserlist.model

data class User(
    val name: String,
    val role: String
)
