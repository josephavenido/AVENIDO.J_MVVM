package com.example.mvvmuserlist.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.mvvmuserlist.model.User
import com.example.mvvmuserlist.repository.UserRepository

class UserViewModel : ViewModel() {

    private val repository = UserRepository()

    val users = MutableLiveData<List<User>>()

    fun loadUsers() {
        users.value = repository.getUsers()
    }
}
