package com.example.mvvmuserlist.repository

import com.example.mvvmuserlist.model.User

class UserRepository {

    fun getUsers(): List<User> {
        return listOf(
            User("Joseph", "Developer"),
            User("Emmanuel", "Designer"),
            User("Daita", "Tester"),
            User("Avenido", "Manager")
        )
    }
}
