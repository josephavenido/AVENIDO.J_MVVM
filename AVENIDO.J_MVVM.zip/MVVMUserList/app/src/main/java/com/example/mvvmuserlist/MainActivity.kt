package com.example.mvvmuserlist

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mvvmuserlist.ui.UserAdapter
import com.example.mvvmuserlist.viewmodel.UserViewModel

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 1. RecyclerView setup
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        val adapter = UserAdapter(emptyList())
        recyclerView.adapter = adapter

        // 2. ViewModel setup
        val viewModel = ViewModelProvider(this)[UserViewModel::class.java]

        // 3. Observe data
        viewModel.users.observe(this) { users ->
            adapter.updateData(users)
        }

        // 4. Load data
        viewModel.loadUsers()
    }
}
